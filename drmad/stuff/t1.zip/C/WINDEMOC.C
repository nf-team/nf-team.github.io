/*-------------------------------------------------------------------------*
*                                                                          *
*  WINDEMOC.A - C window system demo                                       *
*                                                                          *
*  COPYRIGHT (C) 1989..1992 Clarion Software Corporation.                  *
*  All Rights Reserved                                                     *
*                                                                          *
*--------------------------------------------------------------------------*/

#pragma data(stack_size => 20000)

#define _JPI_WIN_

#include <stddef.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>
#if (defined _OS2) && !(defined _XTD)
#include <os2def.h>
#define  INCL_KBD
#include <bsesub.h>
#else
#include <dos.h>
#endif

#ifndef _mthread
#error Must be made in MT model
#endif

typedef enum kfs { RShift,  LShift,  Ctrl,  Alt,  Scroll,  Num,  Cap,  Ins } KBFlagSet;

typedef struct {
    unsigned x,  y;
} WCoor;

typedef WCoor WW[30];

void P1(void);
void P2(void);
void P3(void);
void P4(void);
void P5(void);
void P6(void);
void P7(void);
void P8(void);
void P9(void);

void CheckScrollLock(void);
void SetC(Color cc, Color bwc);
void Intro(void);
void IntroText(void);
void RandPalette(PaletteDef p);
void Rmove(wintype W);
void RChangeSize(wintype W) ;
void DrawBar (unsigned x, unsigned y, unsigned val, int on);
void Demo(void);
void CheckBW(void);
int putchRep(int ch, int num);

int _isbw;
SIGNAL DS;
const WW ww={
    {0, 0},
    {5, 0},
    {10, 0},
    {15, 0},
    {20, 0},
    {10, 2},
    {10, 4},
    {10, 6},
    {10, 8},
    {10, 10},
    {5, 10},
    {0, 10},
    {35, 4},
    {35, 2},
    {35, 0},
    {40, 0},
    {45, 0},
    {50, 2},
    {50, 4}, 
    {45, 6},
    {40, 6},
    {35, 6},
    {35, 8},
    {35, 10},
    {65, 0},
    {65, 2},
    {65, 4},
    {65, 6},
    {65, 8},
    {65, 10}
};

int putchRep(int ch, int num)

{
    int n;

    n=num+1;
    while(--n)
    {
        putch(ch);
    }
    return(num);
}

#if (defined _XTD) || !(defined _OS2)
unsigned KBFlags (void)
{
    union REGS R,R1;
    R.h.ah = 2;
    int86(0x16, &R, &R1);
    return R1.h.al;
}
#else
unsigned KBFlags (void)
{ struct _KBDINFO ks;
  ks.cb = sizeof(ks);
  KbdGetStatus(&ks,0);
  return ks.fsState;
}
#endif

void CheckScrollLock()
{
  if (KBFlags()&0x10) {
    Lock();
    do
      delay(10);
    while (KBFlags()&0x10);
    Unlock();
  }
}

void SetC(Color cc, Color bwc)

{
    if( _isbw)
        cc = bwc;
    textcolor(cc);
    return;
}


void IntroText()

{
    SetC(White,  LightGray);
    cprintf("\n       This is a demonstration of the ");
    SetC(Yellow, White);
    cprintf("Window") ;
    SetC(White, LightGray);
    cprintf(" and ") ;
    SetC(Yellow, White) ;
    cprintf("Process") ;
    SetC(White, LightGray);
    cprintf(" Modules\n\n") ;
    SetC(LightGray, LightGray);
    cprintf("           9 time-sliced processes are created,  which output to, \n");
    cprintf("           move,  re-size and re-colour  4 overlapping windows\n\n");
    SetC(White, White);
    cprintf("     Press any key to start,  Esc to finish ");
    return;
}

int ext,  chnge;
windef DescDef={0, 15, 75, 24, White, Black,
                FALSE, TRUE, FALSE, TRUE,
                DOUBLEFRAME, Blue, LightGray};

void Intro()
/* Display startup and demonstration description */

{

   windef WD;
   wintype w;
   wintype Win[30];
   unsigned i;
   char num[7];
   wintype DescWin;
   unsigned ddelay;

   const int  targetX = 32 ;
   const int  targetY =  5 ;

    for( i = 0; i <= 29; i++ )
    {
        if( _isbw)
        {
            if( i%2 )
            {
                WD.Background = Black ;
                WD.Foreground = White ;
            }
            else
            {
                WD.Background = LightGray ;
                WD.Foreground = Black ;
            }
        }
        else
        {
            WD.Background = i%8 ;
            WD.Foreground = (15-i)% 8 ;
        }
        WD.X1 = ww[i].x;
        WD.Y1 = ww[i].y ;
        WD.X2 = WD.X1+9;
        WD.Y2 = WD.Y1+3;
        WD.CursorOn = FALSE ;
        WD.WrapOn   = FALSE ;
        WD.Hidden   = FALSE ;
        WD.FrameOn  = TRUE ;
        strcpy(WD.FrameDef, SINGLEFRAME);
        if( (!_isbw) && (WD.Background == Black))
            WD.FrameBack  = Green ;
        else
            WD.FrameBack  = WD.Background ;
        if( WD.FrameBack == LightGray)
            WD.FrameFore  = Black ;
        else
            WD.FrameFore  = LightGray ;
        Win[i] = windowopen(&WD) ;
        settitle(Win[i],  "JPI",  CenterUpperTitle);
        ultoa((long) (i+1),  num,  10) ;
     /*
        if( (i=29)||(ww[i].x+5!=ww[i+1].x) ) putch(' "); )
     */
        cprintf("TopSpeed\n");
        cprintf("   C");
    }
    if( _isbw )
        DescDef.FrameFore = Black ;
    DescWin = windowopen(&DescDef) ;
    settitle(DescWin,  " TopSpeed C : Window Demonstration ", CenterUpperTitle);
    use(DescWin);
    IntroText();
    ddelay = 100;
    i = 0 ;
    while( !kbhit() )
    {
        CheckScrollLock();
        if( ddelay > 10 )
            ddelay-=2;
        else if (ddelay > 1 )
            --ddelay;
        delay(ddelay);
        putontop(Win[i]) ;
        i = (i+1)%30 ;
    }
    do
    {
        ext=TRUE;
        for( i = 0; i <= 29; i++ )
        {
            info(Win[i],  &WD) ;
            chnge = TRUE ;
            if(WD.X1 < targetX-3 )
            {
                WD.X1+=3;
                WD.X2+=3;
            }
            else if (WD.X1 > targetX+3)
            {
                WD.X1-=3;
                WD.X2-=3;
            }
            else if(WD.Y1==targetY)
                chnge = FALSE ;
            if(WD.Y1 < targetY )
            {
                ++WD.Y1;
                ++WD.Y2;
            }
            else if(WD.Y1 > targetY)
            {
                --WD.Y1;
                --WD.Y2;
            }
            if( chnge )
            {
                change(Win[i], WD.X1, WD.Y1, WD.X2, WD.Y2) ;
                ext=FALSE;
            }
        }
    }
    while(ext == FALSE);
    for(i = 0; i <= 30; i++)
    {
        w = top();
/*        delay(1);*/
        windowclose(w);
     }
     if( getch()==27 )
         exit(0);
     return;
}

/* Actual demo starts here */
/* ----------------------- */

wintype W1,  W2,  W3,  W4;
int Initialize;
PaletteDef pal;
typedef  Color BW3[3];
const BW3 bw3 ={Black,  LightGray,  White};

/* Random Colouring */

void RandPalette (PaletteDef p)
{
    unsigned i;

    for(i = 0; i < PALETTEMAX ; i++)
    {
        if(_isbw)
            p[i].Fore = bw3[random(3)] ;
        else
            p[i].Fore = random(16);
        do
        {
            if(_isbw)
                p[i].Back = bw3[random(3)];
            else
                p[i].Back = random(8);
        }while(p[i].Back == p[i].Fore);
    }
    return;
}

/* Random Movement */

void Rmove(wintype W)

{
    unsigned dx1, dy1;
    unsigned ix, iy, nx, ny;

    while(1)
    {
        Delay(5+random(16));
        do
        {
            dx1 = W->WDef.X1+(random(16)-8)*2 ;
            dy1 = W->WDef.Y1+random(16)-8 ;
        }
        while(!(( dx1 < 80) && ( dy1 < 24) &&(dx1+W->OWidth <= 80) && (dy1+W->ODepth <= 24)));
        if( dx1>W->WDef.X1 )
            ix = 2;
        else
            ix = 0;
        if( dy1>W->WDef.Y1 )
            iy = 2;
        else
            iy = 0;
        while( (dx1 != W->WDef.X1) && (dy1 != W->WDef.Y1))
        {
            if((dx1 != W->WDef.X1))
                nx=W->WDef.X1+ix-1;
            if((dy1 != W->WDef.Y1))
                ny = W->WDef.Y1+iy-1;
            change(W, nx, ny, nx+W->OWidth-1, ny+W->ODepth-1) ;
        }
    }
}

/* Random Change Size */

void RChangeSize(wintype W)
/* this randomly changes the size of a window */
{
    unsigned nx, ny;

    do
    {
        nx = W->WDef.X2+(random(16)-8)*2 ;
        ny = W->WDef.Y2+random(16)-8 ;
    } while(!((nx-W->WDef.X1 < 70) && (ny-W->WDef.Y1 < 18)
         && (nx-W->WDef.X1 > 10) && (ny-W->WDef.Y1 > 4)));
    change(W, W->WDef.X1, W->WDef.Y1, nx, ny) ;
}


/* Processes */

/* P1 prints out numbers in Hex,  Dec and Binary */

void P1()

{
    char S[31];
    unsigned i = 0;;

    use(W1) ;
    while(1)
    {
        ultoa(i, S, 2);
        cprintf("%-16s%5d  %5.4X\n", S, i, i);
        i++;
    }
}

/* P2 displays out a sideways barchart */

void DrawBar (unsigned x, unsigned y, unsigned val, int on)

{
    if(y%2)
    {
        if( _isbw )
            textcolor(White);
        else
            textcolor(Red) ;
    }
    else
        textcolor(LightGray) ;
    if(val > 0)
    {
        --val;
        gotoxy(x+val/2, y) ;
        if( on )
        {
          if(val%2)
              putch('�');
          else
              putch('�');
        }
        else
        {
          if(val%2)
              putch('�');
          else
              putch(' ');
        }
    }
    return;
}


void P2()

{
    unsigned i, j;
    static unsigned V[10];
    windef WD;

    use(W2) ;
    i = 0 ;
    for(i = 1; i <= 9; i++ )
    {
        V[i] = random(50);
        Lock();
        for(j = 0; j <= V[i]; j++)
        {
            DrawBar(1, i, j, TRUE) ;
        }
        Unlock();
    }
    while(1)
    {
        for(i = 1; i <= 9; i++)
        {
            info(W2, &WD);
            if( i < WD.X2-WD.X1-2 )
            {
                Lock();
                if((random(2)==0 ) && ( V[i]<50 ))
                {
                    ++V[i];
                    DrawBar(1, i, V[i], TRUE);
                }
                else if( V[i] > 0 )
                {
                    DrawBar(1, i, V[i], FALSE);
                    --V[i];
                }
                Unlock();
            }
        }
    }
}

/* P3 displays a character grid with randomly changing pallette colours */

void P3()

{
    unsigned X, Y, D;
    char CH;

    CH = '*' ;
    D = 0 ;
    use(W3) ;
    while(1)
    {
        for( X = 1; X <= 8; X++ )
        {
            Lock();
            for( Y = 1; Y <= 8; Y++ )
            {
                setpalettecolor((Y*7+X+D)%8);
                gotoxy(X, Y);
                putch(CH);
                gotoxy(1, 10);
                setpalettecolor(0) ;
                cprintf("%2d, %d", X, Y);
            }
            Unlock();
        }
        RandPalette( pal ) ;
        setpalette(W3, pal) ;
        ++D;
    }
}

/* P4 displays some text */

void P4()

{
    use(W4) ;
    do
    {
        cprintf("This is a test of 9 time-sliced processes,  and also of window writing,  moving,  rearranging and resizing.");
        W4->WDef.Foreground = White ;
        if( _isbw )
            W4->WDef.Background = Black ;
        cprintf(" Press any key to terminate. ");
        W4->WDef.Foreground = Black ;
        if(_isbw )
            W4->WDef.Background = LightGray;
        if(kbhit())
            goto out;
        CheckScrollLock();
    } while(1);
out:
    SEND(DS);
    while (1)
      Delay(10000);  /* i.e. indefinitely, to give Demo time to StopScheduler */
}

/* P5 Re-sizes and Re-arranges text */

void P5()

{
    while(1)
    {
        Delay(10+random(10));
        switch(random(4))
        {
            case 0 :
                putontop(W1);
                break;
            case 1 :
                putontop(W2);
                break;
            case 2 :
                putontop(W3);
                break;
            case 3 :
                putontop(W4);
                break;
        }
        Delay(10+random(10));
        switch(random(4))
        {
            case 0 :
                RChangeSize(W1);
                break;
            case 3 :
                RChangeSize(W4);
                break;
        }
    }
}

/* P6 Moves window 1 */

void  P6()

{
    Rmove(W1);   /* never returns */
}

/* P7 Moves window 2 */

void  P7()

{
    Rmove(W2);  /* never returns */
}

/* P8 Moves window 2 */

void  P8()

{
    Rmove(W3);  /* never returns */
}

/* P9 Moves window 2 */

void  P9()

{
    Rmove(W4);  /* never returns */
}


void Demo()

{
    windef WD;

    randomize();
    Initialize = TRUE ;
    cursoroff();
    clrscr();
    WD.X1 = 10;
    WD.Y1 = 2 ;
    WD.X2 = 60;
    WD.Y2 = 8 ;
    WD.Foreground = White ;
    if(_isbw )
        WD.Background = Black ;
    else
        WD.Background = Red ;
    WD.CursorOn   = FALSE ;
    WD.WrapOn     = FALSE ;
    WD.Hidden     = FALSE ;
    WD.FrameOn    = TRUE ;
    strcpy(WD.FrameDef, SINGLEFRAME);
    WD.FrameFore  = White ;
    WD.FrameBack  = WD.Background ;
    W1 = windowopen(&WD) ;
    settitle(W1, " Process 1 ", CenterUpperTitle);
    WD.X1 = 40;
    WD.Y1 = 2 ;
    WD.X2 = 70;
    WD.Y2 = 12 ;
    WD.Foreground = White ;
    WD.Background = Blue ;
    WD.CursorOn   = FALSE ;
    WD.WrapOn     = TRUE ;
    WD.Hidden     = FALSE ;
    WD.FrameOn    = TRUE ;
    strcpy(WD.FrameDef, DOUBLEFRAME);
    WD.FrameFore  = Black ;
    WD.FrameBack  = Cyan ;
    if( _isbw )
    {
        WD.Background = Black ;
        WD.FrameBack = LightGray;
    }
    W2 = windowopen(&WD) ;
    settitle(W2, " Process 2 ", CenterUpperTitle);
    RandPalette(pal) ;
    WD.X1 = 40;
    WD.Y1 = 6 ;
    WD.X2 = 50;
    WD.Y2 = 17 ;
    pal[0].Fore= Yellow ;
    pal[0].Back= Black ;
    WD.CursorOn= FALSE ;
    WD.WrapOn     = TRUE ;
    WD.Hidden     = FALSE ;
    WD.FrameOn    = TRUE ;
    strcpy(WD.FrameDef, SINGLEFRAME);
    pal[1].Fore= White ;
    pal[1].Back= Green ;
    if(_isbw )
    {
        pal[0].Fore= LightGray ;
        pal[1].Back= Black ;
    }
    W3 = paletteopen(&WD, pal) ;
    settitle(W3, " Process 3 ", CenterUpperTitle);
    WD.X1 = 10;
    WD.Y1 = 10;
    WD.X2 = 70;
    WD.Y2 = 20 ;
    WD.Foreground = Black ;
    WD.Background = LightGray ;
    WD.CursorOn   = FALSE ;
    WD.WrapOn     = TRUE ;
    WD.Hidden     = FALSE ;
    WD.FrameOn    = TRUE ;
    strcpy(WD.FrameDef, DOUBLEFRAME);
    WD.FrameFore  = White ;
    WD.FrameBack  = Green ;
    if( _isbw )
        WD.FrameBack  = Black ;
    W4 = windowopen(&WD) ;
    settitle(W4, " Process 4 ", CenterUpperTitle);

    StartScheduler();
    Init(&DS);
    StartProcess(P1, 2000, 0);
    StartProcess(P2, 2000, 0);
    StartProcess(P3, 2000, 0);
    StartProcess(P4, 2000, 0);
    StartProcess(P5, 2000, 0);
    StartProcess(P6, 2000, 0);
    StartProcess(P7, 2000, 0);
    StartProcess(P8, 2000, 0);
    StartProcess(P9, 2000, 0);
    WAIT(DS);
    StopScheduler();
    use(_fullscreen) ;
    snapshot();
    putontop(_fullscreen);
    gotoxy(1, SCREENDEPTH-1);
    cursoron();
    clrscr();
    return;
}

void CheckBW()

{
   _isbw = FALSE;
   return;
}


int main()

{
    clrscr();
    CheckBW();
    Intro();
    Demo();
    return(0);
}


