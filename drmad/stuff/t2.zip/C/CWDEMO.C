#pragma warn(wall => on)
#pragma warn(wpnu => off)

#include "windows.h"
#include <alloc.h>

/* String table constants */
#define IDSNAME     100
#define IDSABOUT    200
#define IDSTITLE    300

/* About Dialog box resource id */
#define ABOUTBOX    1

char szAppName[10];
char szAbout[10];
char szMessage[20];
int MessageLength;

HANDLE hInst;
FARPROC lpprocAbout;

#pragma save
#pragma call( windows => on )
long FAR PASCAL WndProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL About(HWND hDlg, unsigned message, WORD wParam, LONG lParam );
#pragma restore

BOOL FAR PASCAL About(HWND hDlg, unsigned message, WORD wParam, LONG lParam )

{
    if (message == WM_COMMAND)
    {
        EndDialog( hDlg, TRUE );
        return(TRUE);
    }
    else if (message == WM_INITDIALOG)
        return(TRUE);
    else
        return(FALSE);
}


void MessagePaint(HDC hdc)

{
    TextOut(hdc, (short)10, (short)10, (LPSTR)szMessage, (short)MessageLength );
    return;
}


/* This procedure called when the program is loaded for the first time */
BOOL DemoInit(HANDLE hInstance)

{
    PWNDCLASS   pDemoClass;

    /* Load strings from resource */
    LoadString(hInstance, IDSNAME, (LPSTR)szAppName, 10);
    LoadString(hInstance, IDSABOUT, (LPSTR)szAbout, 10);
    MessageLength=LoadString(hInstance, IDSTITLE, (LPSTR)szMessage, 20);
/*    pDemoClass=(PWNDCLASS)malloc(sizeof(WNDCLASS));*/
    pDemoClass = (PWNDCLASS)LocalAlloc( LPTR, sizeof(WNDCLASS) );

    pDemoClass->hCursor=LoadCursor(NULL, IDC_ARROW);
    pDemoClass->hIcon=LoadIcon(hInstance,(LPSTR)"wdemo");
    pDemoClass->lpszMenuName=(LPSTR)NULL;
    pDemoClass->lpszClassName=(LPSTR)szAppName;
    pDemoClass->hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
    pDemoClass->hInstance=hInstance;
    pDemoClass->style= CS_HREDRAW | CS_VREDRAW;
    pDemoClass->lpfnWndProc=WndProc;
    pDemoClass->cbClsExtra = 0;
    pDemoClass->cbWndExtra = 0;

    if(!RegisterClass((LPWNDCLASS)pDemoClass))
        /* Initialization failed.
         * Windows will automatically deallocate all allocated memory.
         */
        return(FALSE);
/*    free(pDemoClass);*/
    LocalFree( (HANDLE)pDemoClass );
    return(TRUE);        /* Success */
}


int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdLine, int cmdShow)

{
    MSG   msg;
    HWND  hWnd;
    HMENU hMenu;

    if (!hPrevInstance)
    {
        /* Call initialization procedure if this is the first instance */
        if (!DemoInit(hInstance))
            return(FALSE);
    }
    else
    {
        /* Copy data from previous instance */
        GetInstanceData(hPrevInstance, (PSTR)szAppName, 10);
        GetInstanceData(hPrevInstance, (PSTR)szAbout, 10);
        GetInstanceData(hPrevInstance, (PSTR)szMessage, 20);
        GetInstanceData(hPrevInstance, (PSTR)&MessageLength, sizeof(int));
    }
    hWnd = CreateWindow((LPSTR)szAppName,
                        (LPSTR)szMessage,
                        WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        (HWND)NULL,        /* no parent */
                        (HMENU)NULL,       /* use class menu */
                        (HANDLE)hInstance, /* handle to window instance */
                        (LPSTR)NULL        /* no params to pass on */
                        );

    /* Save instance handle for DialogBox */
    hInst=hInstance;
    lpprocAbout = MakeProcInstance( (FARPROC)About, hInstance );

    /* Insert About */
    hMenu=GetSystemMenu(hWnd, FALSE);
    ChangeMenu(hMenu, 0, NULL, 999, MF_APPEND | MF_SEPARATOR);
    ChangeMenu(hMenu, 0, (LPSTR)szAbout, IDSABOUT, MF_APPEND | MF_STRING);

    /* Make window visible according to the way the app is activated */
    ShowWindow(hWnd, cmdShow);
    UpdateWindow(hWnd);

    /* Polling messages from event queue */
    while (GetMessage((LPMSG)&msg, NULL, 0, 0))
    {
        TranslateMessage((LPMSG)&msg);
        DispatchMessage((LPMSG)&msg);
    }
    return ((int)msg.wParam);
}


/* Procedures which make up the window class. */
long FAR PASCAL WndProc(HWND hWnd, unsigned message, WORD wParam, LONG lParam )

{
    PAINTSTRUCT ps;

    switch (message)
    {
        case WM_SYSCOMMAND:
            switch (wParam)
            {
                case IDSABOUT:
                    DialogBox( hInst, MAKEINTRESOURCE(ABOUTBOX), hWnd, lpprocAbout );
                    break;
                default:
                return(DefWindowProc( hWnd, message, wParam, lParam));
            }
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        case WM_PAINT:
            BeginPaint(hWnd, (LPPAINTSTRUCT)&ps);
            MessagePaint(ps.hdc);
            EndPaint(hWnd, (LPPAINTSTRUCT)&ps );
            break;
        default:
            return(DefWindowProc( hWnd, message, wParam, lParam));
            break;
    }
    return(0);
}
